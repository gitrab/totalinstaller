# totalXBMC Installer based on original XBMCHUB.com Addon Installer  Module By: Blazetamer-2013-2014
import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,sys,time,shutil
import downloader
import extract
addon_id='plugin.program.totalinstaller'
try: 		from t0mm0.common.addon import Addon
except: from t0mm0_common_addon import Addon
addon=Addon(addon_id, sys.argv)
try: 		from t0mm0.common.net import Net
except: from t0mm0_common_net import Net
net = Net()
settings=xbmcaddon.Addon(id='plugin.program.totalinstaller')
base_url = 'http://addons.totalxbmc.tv/'


artPath = xbmc.translatePath(os.path.join('special://home/addons','plugin.program.totalinstaller/resources/art/'))
ADDON = xbmcaddon.Addon(id='plugin.program.totalinstaller')
fanart = artPath + 'fanart.jpg'


def MAININDEX():
    #totalxbmcpath=xbmc.translatePath(os.path.join('special://home/addons','repository.totalxbmc'))
    #if not os.path.exists(totalxbmcpath): TOTALINSTALL('totalxbmcrepo','http://totalxbmc.googlecode.com/svn/addons/repository.totalxbmc/repository.totalxbmc-1.0.0.zip','','addon','none')
    #addDir('Top 5 Addons','http://addons.totalxbmc.tv/addonlists/livetvtop5.php','featuredindex',artPath + 'featuredaddonsa.jpg')
    if settings.getSetting('categories') == 'true':
        addDir('Categories','none','categories',artPath +'categories2.png')
    if settings.getSetting('genre') == 'true':
        addDir('Genres','none','genres',artPath +'genres.png')
    if settings.getSetting('countries') == 'true':
        addDir('Countries','none','countries',artPath +'countries.png')
    if settings.getSetting('repositories') == 'true':
        addDir('Repositories','http://addons.totalxbmc.tv/category/repositories/','addonlist',artPath +'repositories.png')
    addDir('Search by: Addon/Author','http://addons.xbmchub.com/search/?keyword=','searchaddon',artPath + 'search.png')

    
def OTHERS():
    addDir('General Standalone Addons','http://tribeca.xbmchub.com/tools/installer/sources/general-solo.php','otherlist',artPath + 'othera.jpg')
    addDir('World Standalone Addons','http://tribeca.xbmchub.com/tools/installer/sources/world-solo.php','worldlist',artPath + 'worlda.jpg')
    #addDir('Adult Addons','http://tribeca.xbmchub.com/tools/installer/sources/xxx.php','adultlist',artPath + 'adult.jpg')

def CATEGORIES():        
    if settings.getSetting('audio') == 'true':
        addDir('Audio Addons','http://addons.totalxbmc.tv/category/categories2/audio/','addonlist',artPath + 'audio.png')
    if settings.getSetting('lyrics') == 'true':
        addDir('Lyrics Addons','http://addons.totalxbmc.tv/category/categories2/lyrics/','addonlist',artPath + 'lyrics.png')
    if settings.getSetting('metadata') == 'true':
        addDir('Metadata','none','metadata',artPath + 'metadata.png')
    if settings.getSetting('pictures') == 'true':
        addDir('Picture Addons','http://addons.totalxbmc.tv/category/categories2/pictures/','addonlist',artPath + 'pictures.png')
    if settings.getSetting('program') == 'true':
        addDir('Program Addons','http://addons.totalxbmc.tv/category/categories2/programs/','programlist',artPath + 'programs.png')
    if settings.getSetting('screensaver') == 'true':
        addDir('Screensavers','http://addons.totalxbmc.tv/category/categories2/screensaver/','addonlist',artPath + 'screensaver.png')
    if settings.getSetting('services') == 'true':
        addDir('Services','http://addons.totalxbmc.tv/category/categories2/services/','addonlist',artPath + 'services.png')
    if settings.getSetting('skin') == 'true':
        addDir('Skins','http://addons.totalxbmc.tv/category/categories2/skins/','addonlist',artPath + 'skins.png')
    if settings.getSetting('subtitles') == 'true':
        addDir('Subtitles','http://addons.totalxbmc.tv/category/categories2/subtitles/','addonlist',artPath + 'subtitles.png')
    if settings.getSetting('video') == 'true':
        addDir('Video Addons','http://addons.totalxbmc.tv/category/categories2/video/','addonlist',artPath + 'video.png')
    if settings.getSetting('weather') == 'true':
        addDir('Weather','http://addons.totalxbmc.tv/category/categories2/weather/','addonlist',artPath + 'weather.png')
    if settings.getSetting('webinterface') == 'true':
        addDir('Web Interface','http://addons.totalxbmc.tv/category/categories2/webinterface/','addonlist',artPath + 'webinterface.png')  
    AUTO_VIEW('')

def METADATA():        
    if settings.getSetting('metaalbums') == 'true':
        addDir('Album Metadata','http://addons.totalxbmc.tv/category/categories2/metadata/artists/','addonlist',artPath + 'albums.png')
    if settings.getSetting('metaartists') == 'true':
        addDir('Artist Metadata','http://addons.totalxbmc.tv/category/categories2/metadata/albums/','addonlist',artPath + 'artists.png')
    if settings.getSetting('metamovies') == 'true':
        addDir('Movie Metadata','http://addons.totalxbmc.tv/category/categories2/metadata/movies/','addonlist',artPath + 'movies.png')
    if settings.getSetting('metamusicvids') == 'true':
        addDir('Music Video Metadata','http://addons.totalxbmc.tv/category/categories2/metadata/musicvideos/','addonlist',artPath + 'musicvids.png')
    if settings.getSetting('metatv') == 'true':
        addDir('TV Metadata','http://addons.totalxbmc.tv/category/categories2/metadata/tvshows/','addonlist',artPath + 'tv.png')
    AUTO_VIEW('')

def GENRES():        
    if settings.getSetting('anime') == 'true':
        addDir('Anime','http://addons.totalxbmc.tv/category/genres/anime/','addonlist',artPath + 'anime.png')
    if settings.getSetting('audiobooks') == 'true':
        addDir('Audiobooks','http://addons.totalxbmc.tv/category/genres/audiobooks/','addonlist',artPath + 'audiobooks.png')
    if settings.getSetting('comics') == 'true':
        addDir('Comics','http://addons.totalxbmc.tv/category/genres/comics/','addonlist',artPath + 'comics.png')
    if settings.getSetting('documentary') == 'true':
        addDir('Documentary','http://addons.totalxbmc.tv/category/genres/documentary/','addonlist',artPath + 'documentary.png')
    if settings.getSetting('food') == 'true':
        addDir('Food','http://addons.totalxbmc.tv/category/genres/food/','addonlist',artPath + 'programs.png')
    if settings.getSetting('gaming') == 'true':
        addDir('Gaming','none','gaming',artPath + 'gaming.png')
    if settings.getSetting('howto') == 'true':
        addDir('How To...','http://addons.totalxbmc.tv/category/genres/howto/','addonlist',artPath + 'howto.png')
    if settings.getSetting('livetv') == 'true':
        addDir('Live TV','http://addons.totalxbmc.tv/category/genres/livetv/','addonlist',artPath + 'livetv.png')
    if settings.getSetting('movies') == 'true':
        addDir('Movies','http://addons.totalxbmc.tv/category/genres/movies/','addonlist',artPath + 'movies.png')
    if settings.getSetting('music') == 'true':
        addDir('Music','none','music',artPath + 'music.png')
    if settings.getSetting('news') == 'true':
        addDir('News & Weather','http://addons.totalxbmc.tv/category/genres/news/','addonlist',artPath + 'news.png')
    if settings.getSetting('podcasts') == 'true':
        addDir('Podcasts','http://addons.totalxbmc.tv/category/genres/podcasts/','addonlist',artPath + 'podcasts.png') 
    if settings.getSetting('radio') == 'true':
        addDir('Radio','http://addons.totalxbmc.tv/category/genres/radio/','addonlist',artPath + 'radio.png')
    if settings.getSetting('religion') == 'true':
        addDir('Religion','http://addons.totalxbmc.tv/category/genres/religion/','addonlist',artPath + 'religion.png')
    if settings.getSetting('movies') == 'true':
        addDir('Sports','http://addons.totalxbmc.tv/category/genres/sports/','addonlist',artPath + 'sports.png')
    if settings.getSetting('technology') == 'true':
        addDir('Technology','http://addons.totalxbmc.tv/category/genres/tech/','addonlist',artPath + 'tech.png')
    if settings.getSetting('trailers') == 'true':
        addDir('Trailers','http://addons.totalxbmc.tv/category/genres/trailers/','addonlist',artPath + 'trailers.png')
    if settings.getSetting('tvshows') == 'true':
        addDir('TV Shows','http://addons.totalxbmc.tv/category/genres/tv/','addonlist',artPath + 'tv.png') 
    if settings.getSetting('misc') == 'true':
        addDir('Misc.','http://addons.totalxbmc.tv/category/genres/other/','addonlist',artPath + 'other.png')
    if settings.getSetting('adult') == 'true':
        addDir('XXX','http://addons.totalxbmc.tv/category/genres/adult/','addonlist',artPath + 'xxx.png') 
    AUTO_VIEW('')
    
def GAMING():        
    addDir('Games','http://addons.totalxbmc.tv/category/genres/gaming/games/','addonlist',artPath + 'games.png')
    addDir('Gaming Videos','http://addons.totalxbmc.tv/category/genres/gaming/gamingvids/','addonlist',artPath + 'gamingvids.png')
    AUTO_VIEW('')
    
def MUSIC():        
    addDir('Music','http://addons.totalxbmc.tv/category/genres/music/musicaudio/','addonlist',artPath + 'musicaudio.png')
    addDir('Music Videos','http://addons.totalxbmc.tv/category/genres/music/musicvids/','addonlist',artPath + 'musicvids.png')
    AUTO_VIEW('')
    
def COUNTRIES():        
    if settings.getSetting('african') == 'true':
        addDir('African','http://addons.totalxbmc.tv/category/countries/african/','addonlist',artPath + 'african.png')
    if settings.getSetting('arabic') == 'true':
        addDir('Arabic','http://addons.totalxbmc.tv/category/countries/arabic/','addonlist',artPath + 'arabic.png')
    if settings.getSetting('asian') == 'true':
        addDir('Asian','http://addons.totalxbmc.tv/category/countries/asian/','addonlist',artPath + 'asian.png')
    if settings.getSetting('australian') == 'true':
        addDir('Australian','http://addons.totalxbmc.tv/category/countries/australian/','addonlist',artPath + 'australian.png')
    if settings.getSetting('austrian') == 'true':
        addDir('Austrian','http://addons.totalxbmc.tv/category/countries/austrian/','addonlist',artPath + 'austrian.png')
    if settings.getSetting('belgian') == 'true':
        addDir('Belgian','http://addons.totalxbmc.tv/category/countries/belgian/','addonlist',artPath + 'belgian.png')
    if settings.getSetting('canadian') == 'true':
        addDir('Canadian','http://addons.totalxbmc.tv/category/countries/canadian/','addonlist',artPath + 'canadian.png')
    if settings.getSetting('chinese') == 'true':
        addDir('Chinese','http://addons.totalxbmc.tv/category/countries/chinese/','addonlist',artPath + 'chinese.png')
    if settings.getSetting('columbian') == 'true':
        addDir('Columbian','http://addons.totalxbmc.tv/category/countries/columbian/','addonlist',artPath + 'columbian.png')
    if settings.getSetting('czech') == 'true':
        addDir('Czech','http://addons.totalxbmc.tv/category/countries/czech/','addonlist',artPath + 'czech.png')
    if settings.getSetting('danish') == 'true':
        addDir('Danish','http://addons.totalxbmc.tv/category/countries/danish/','addonlist',artPath + 'danish.png')
    if settings.getSetting('dominican') == 'true':
        addDir('Dominican','http://addons.totalxbmc.tv/category/countries/dominican/','addonlist',artPath + 'podcasts.png') 
    if settings.getSetting('dutch') == 'true':
        addDir('Dutch','http://addons.totalxbmc.tv/category/countries/dutch/','addonlist',artPath + 'dutch.png')
    if settings.getSetting('filipino') == 'true':
        addDir('Filipino','http://addons.totalxbmc.tv/category/countries/filipino/','addonlist',artPath + 'filipino.png')
    if settings.getSetting('finnish') == 'true':
        addDir('Finnish','http://addons.totalxbmc.tv/category/countries/finnish/','addonlist',artPath + 'finnish.png')
    if settings.getSetting('french') == 'true':
        addDir('French','http://addons.totalxbmc.tv/category/countries/french/','addonlist',artPath + 'french.png')
    if settings.getSetting('german') == 'true':
        addDir('German','http://addons.totalxbmc.tv/category/countries/german/','addonlist',artPath + 'german.png')
    if settings.getSetting('greek') == 'true':
        addDir('Greek','http://addons.totalxbmc.tv/category/countries/greek/','addonlist',artPath + 'greek.png') 
    if settings.getSetting('hebrew') == 'true':
        addDir('Hebrew','http://addons.totalxbmc.tv/category/countries/hebrew/','addonlist',artPath + 'hebrew.png')
    if settings.getSetting('hungarian') == 'true':
        addDir('Hungarian','http://addons.totalxbmc.tv/category/countries/hungarian/','addonlist',artPath + 'hungarian.png') 
    if settings.getSetting('icelandic') == 'true':
        addDir('Icelandic','http://addons.totalxbmc.tv/category/countries/icelandic/','addonlist',artPath + 'icelandic.png')
    if settings.getSetting('indian') == 'true':
        addDir('Indian','http://addons.totalxbmc.tv/category/countries/indian/','addonlist',artPath + 'indian.png')
    if settings.getSetting('irish') == 'true':
        addDir('Irish','http://addons.totalxbmc.tv/category/countries/irish/','addonlist',artPath + 'irish.png')
    if settings.getSetting('italian') == 'true':
        addDir('Italian','http://addons.totalxbmc.tv/category/countries/italian/','addonlist',artPath + 'italian.png')
    if settings.getSetting('japanese') == 'true':
        addDir('Japanese','http://addons.totalxbmc.tv/category/countries/japanese/','addonlist',artPath + 'japanese.png')
    if settings.getSetting('korean') == 'true':
        addDir('Korean','http://addons.totalxbmc.tv/category/countries/korean/','addonlist',artPath + 'korean.png')
    if settings.getSetting('moroccan') == 'true':
        addDir('Moroccan','http://addons.totalxbmc.tv/category/countries/moroccan/','addonlist',artPath + 'moroccan.png')
    if settings.getSetting('nepali') == 'true':
        addDir('Nepali','http://addons.totalxbmc.tv/category/countries/nepali/','addonlist',artPath + 'nepali.png')
    if settings.getSetting('newzealand') == 'true':
        addDir('New Zealand','http://addons.totalxbmc.tv/category/countries/newzealand/','addonlist',artPath + 'newzealand.png') 
    if settings.getSetting('norwegian') == 'true':
        addDir('Norwegian','http://addons.totalxbmc.tv/category/countries/norwegian/','addonlist',artPath + 'norwegian.png')
    if settings.getSetting('pakistani') == 'true':
        addDir('Pakistani','http://addons.totalxbmc.tv/category/countries/pakistani/','addonlist',artPath + 'pakistani.png')
    if settings.getSetting('polish') == 'true':
        addDir('Polish','http://addons.totalxbmc.tv/category/countries/polish/','addonlist',artPath + 'polish.png')
    if settings.getSetting('portuguese') == 'true':
        addDir('Portuguese','http://addons.totalxbmc.tv/category/countries/portuguese/','addonlist',artPath + 'portuguese.png')
    if settings.getSetting('romanian') == 'true':
        addDir('Romanian','http://addons.totalxbmc.tv/category/countries/romanian/','addonlist',artPath + 'romanian.png')
    if settings.getSetting('russian') == 'true':
        addDir('Russian','http://addons.totalxbmc.tv/category/countries/russian/','addonlist',artPath + 'russian.png') 
    if settings.getSetting('singapore') == 'true':
        addDir('Singapore','http://addons.totalxbmc.tv/category/countries/singapore/','addonlist',artPath + 'singapore.png')
    if settings.getSetting('spanish') == 'true':
        addDir('Spanish','http://addons.totalxbmc.tv/category/countries/spanish/','addonlist',artPath + 'spanish.png') 
    if settings.getSetting('swedish') == 'true':
        addDir('Swedish','http://addons.totalxbmc.tv/category/countries/swedish/','addonlist',artPath + 'swedish.png') 
    if settings.getSetting('swiss') == 'true':
        addDir('Swiss','http://addons.totalxbmc.tv/category/countries/swiss/','addonlist',artPath + 'swiss.png')
    if settings.getSetting('tamil') == 'true':
        addDir('Tamil','http://addons.totalxbmc.tv/category/countries/tamil/','addonlist',artPath + 'tamil.png')
    if settings.getSetting('thai') == 'true':
        addDir('Thai','http://addons.totalxbmc.tv/category/countries/thai/','addonlist',artPath + 'thai.png')
    if settings.getSetting('turkish') == 'true':
        addDir('Turkish','http://addons.totalxbmc.tv/category/countries/turkish/','addonlist',artPath + 'turkish.png')
    if settings.getSetting('uk') == 'true':
        addDir('UK','http://addons.totalxbmc.tv/category/countries/uk/','addonlist',artPath + 'uk.png')
    if settings.getSetting('usa') == 'true':
        addDir('USA','http://addons.totalxbmc.tv/category/countries/usa/','addonlist',artPath + 'usa.png') 
    if settings.getSetting('vietnamese') == 'true':
        addDir('Vietnamese','http://addons.totalxbmc.tv/category/countries/vietnamese/','addonlist',artPath + 'vietnamese.png') 
    AUTO_VIEW('')
    
def FEATUREDINDEX(url):
    link=OPEN_URL(url).replace('\r','').replace('\n','').replace('\t','')
    match=re.compile('name="(.+?)"url="(.+?)"').findall(link)
    for name,url, in match:
        add2HELPDir(name,url,'addonindex',fanart,fanart,'','addon')
    AUTO_VIEW('')
    
def REPOLIST(url):
    fanart = artPath + 'fanart.jpg'
    #mainurl= url
    link=OPEN_URL(url)
    match=re.compile('<li><a href="(.+?)"><span class="thumbnail"><img src="(.+?)" width="100%" alt="(.+?)"').findall(link)
    for url,image,name, in match:
        iconimage = base_url + image
        if 'repo' in name or 'repository' in name or 'Repo' in name or 'Repository' in name:
            add2HELPDir(name,url,'addonindex',iconimage,fanart,'','addon')                   
        nmatch=re.compile('"page last" href="(.+?)"><dfn title="next Page">').findall(link)
    if len(nmatch) > 0:
        addDir('Next Page',(nmatch[0]),'repolist','')    
    AUTO_VIEW('list')    

def ADDONLIST(url):
    fanart = artPath + 'fanart.jpg'
    #mainurl= url
    link=OPEN_URL(url)
    match=re.compile('<li><a href="(.+?)"><span class="thumbnail"><img src="(.+?)" width="100%" alt="(.+?)"').findall(link)
    for url,image,name, in match:
        iconimage = base_url + image
        add2HELPDir(name,url,'addonindex',iconimage,fanart,'','addon')                    
        nmatch=re.compile('"page last" href="(.+?)"><dfn title="next Page">').findall(link)
    #WORLDLIST('http://tribeca.xbmchub.com/tools/installer/sources/world-solo.php')
    #OTHERLIST('http://tribeca.xbmchub.com/tools/installer/sources/general-solo.php')   
    #addDir('Standalone Addons','none','others',artPath + 'other.jpg')
    if len(nmatch) > 0:
        addDir('Next Page',(nmatch[0]),'addonlistnext','')
    AUTO_VIEW('list')

def PROGRAMLIST(url):
    fanart = artPath + 'fanart.jpg'
    #mainurl= url
    link=OPEN_URL(url)
    match=re.compile('<li><a href="(.+?)"><span class="thumbnail"><img src="(.+?)" width="100%" alt="(.+?)"').findall(link)
    for url,image,name, in match:
        iconimage = base_url + image
        add2HELPDir(name,url,'addonindex',iconimage,fanart,'','addon')                    
        nmatch=re.compile('"page last" href="(.+?)"><dfn title="next Page">').findall(link)
    #WORLDLIST('http://tribeca.xbmchub.com/tools/installer/sources/world-solo.php')
    #OTHERLIST('http://tribeca.xbmchub.com/tools/installer/sources/general-solo.php')   
    #addDir('Standalone Addons','none','others',artPath + 'other.jpg')
    if len(nmatch) > 0:
        addDir('Next Page',(nmatch[0]),'addonlistnext','')
    AUTO_VIEW('list')    

def ADDONLISTNEXT(url):
    fanart = artPath + 'fanart.jpg'
    #mainurl= url
    link=OPEN_URL(url)
    match=re.compile('<li><a href="(.+?)"><span class="thumbnail"><img src="(.+?)" width="100%" alt="(.+?)"').findall(link)
    for url,image,name, in match:
        iconimage = base_url + image
        add2HELPDir(name,url,'addonindex',iconimage,fanart,'','addon')                    
        nmatch=re.compile('"page last" href="(.+?)"><dfn title="next Page">').findall(link)
    if len(nmatch) > 0:
        addDir('Next Page',(nmatch[0]),'addonlistnext','')
    AUTO_VIEW('list')

def WORLDALONE(url):
    fanart = artPath + 'fanart.jpg'
    #mainurl= url
    link=OPEN_URL(url).replace('\r','').replace('\n','').replace('\t','')
    match=re.compile("'name' => '(.+?)','language' => '(.+?)'.+?downloadUrl' => '(.+?)'").findall(link)
    for name,lang,dload in match:
                lang=lang.capitalize()        
                addHELPDir(name +' ('+lang+')' ,dload,'addoninstall','',fanart,'','addon','none','','')
                AUTO_VIEW('')

                
def WORLDLIST(url):
    fanart = artPath + 'fanart.jpg'
    #mainurl= url
    link=OPEN_URL(url).replace('\r','').replace('\n','').replace('\t','')
    match=re.compile("'name' => '(.+?)','language' => '(.+?)'.+?downloadUrl' => '(.+?)'").findall(link)
    for name,lang,dload in match:
                lang=lang.capitalize()        
                addHELPDir(name +' ('+lang+')' ,dload,'addoninstall','',fanart,'','addon','none','','')
    WORLDALONE('http://tribeca.xbmchub.com/tools/installer/sources/world-solo.php')
    AUTO_VIEW('list')    

def OTHERLIST(url):
    fanart = artPath + 'fanart.jpg'
    link=OPEN_URL(url).replace('\r','').replace('\n','').replace('\t','')
    match=re.compile("'name' => '(.+?)','type' => '(.+?)'.+?downloadUrl' => '(.+?)'").findall(link)
    #match=re.compile("'name' => '(.+?)'").findall(link)
    if len(match) > 0:
     for name,lang,dload in match:
                lang=lang.capitalize()
                addHELPDir(name +' ('+lang+')' ,dload,'addoninstall','',fanart,'','addon','none','','')
                    #addHELPDir(name,dload,'addoninstall','',fanart,'','addon','none','','')   
                AUTO_VIEW('')

def FEATUREDADDONS(url):
    fanart = artPath + 'fanart.jpg'
    #mainurl= url
    link=OPEN_URL(url).replace('\r','').replace('\n','').replace('\t','')
    match=re.compile("'name' => '(.+?)'").findall(link)
    for name in match:
        match2=re.compile("downloadUrl' => '(.+?)'").findall(link)
        for dload in match2:
                lang='Featured'
                name = name.replace('&rsquo;',"'")
                name=name.capitalize()
        addHELPDir(name +' ('+lang+')' ,dload,'addoninstall','',fanart,'','addon','none','','')                      
        AUTO_VIEW('')         

def ADULTLIST(url):
    fanart = artPath + 'fanart.jpg'
    #mainurl= url
    link=OPEN_URL(url).replace('\r','').replace('\n','').replace('\t','')
    match=re.compile("'name' => '(.+?)'").findall(link)
    for name in match:
        match2=re.compile("downloadUrl' => '(.+?)'").findall(link)
        for dload in match2:
                lang='Adults Only'
        addHELPDir(name +' ('+lang+')' ,dload,'addoninstall','',fanart,'','addon','none','','')                      
        AUTO_VIEW('')               

    
def ADDONINDEX(name,url,filetype):
    fanart = artPath + 'fanart.jpg'
    link=OPEN_URL(url)
    #match=re.compile('<img src="(.+?)" alt=".+?" class="pic" /></span>\r\n\t\t\t\t<h2>(.+?)</h2>\r\n\t\t\t\t<strong>Author:</strong> <a href=".+?">.+?</a><br /><strong>Version:</strong> .+?<br /><strong>Released:</strong> .+?<br /><strong>Repository:</strong> <a href="(.+?)" rel="nofollow">.+?</a><div class="description"><h4>Description:</h4><p> (.+?)</p></div><ul class="addonLinks"><li><strong>Forum Discussion:</strong><br /><a href=".+?" target="_blank"><img src="images/forum.png" alt="Forum discussion" /></a></li><li><strong>Source Code:</strong><br /><img src="images/codebw.png" alt="Source code" /></li><li><strong>Website:</strong><br /><a href=".+?" target="_blank"><img src="images/website.png" alt="Website" /></a></li><li><strong>Direct Download:</strong><br /><a href="(.+?)" rel="nofollow">').findall(link)
    description = 'Description not available at this time'
    match2=re.compile('<img src="(.+?)" alt=".+?" class="pic" /></span>').findall(link)
    for image in match2:
        match3=re.compile('class="pic" /></span>\s*<h2>(.+?)</h2>').findall(link)
        for name in match3:
            match4=re.compile('Repository:</strong> <a href="(.+?)"').findall(link)
            for repourl in match4:
                link=OPEN_URL(url).replace('\n','').replace('\t','')
                match5=re.compile('Description:</h4><p>(.+?)</p>').findall(link)
                for description in match5:
                    if len(match5) <1:
                            description = 'No Description available' 
                    link=OPEN_URL(url)     
                    match6=re.compile('Download:</strong><br /><a href="(.+?)"').findall(link)
                    for addonurl in match6:
                        iconimage = base_url + image
                    match7=re.compile('Author:</strong> <a href=".+?">(.+?)</a>').findall(link)
                    for author in match7:
                         match8=re.compile('Version:</strong>(.+?)<br').findall(link)
                         for version in match8:
    
                             addHELPDir('Install '+name,addonurl,'addoninstall',iconimage,fanart,description,'addon',repourl,version,author)
                             #ADDONINSTALL(name,addonurl,description,'addon',repourl)
                             AUTO_VIEW('addons')
    
    

  
def OPEN_URL(url):
  req=urllib2.Request(url)
  req.add_header('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
  response=urllib2.urlopen(req)
  link=response.read()
  response.close()
  return link

def TOTALINSTALL(name,url,description,filetype,repourl):
        path=xbmc.translatePath(os.path.join('special://home/addons','packages'))
        dp=xbmcgui.DialogProgress()
        dp.create("First Launch:","Creating Database ",'','Only Shown on First Launch')
        lib=os.path.join(path,name+'.zip')
        try: os.remove(lib)
        except: pass
        downloader.download(url, lib, dp)
        if filetype == 'addon':
            addonfolder = xbmc.translatePath(os.path.join('special://','home/addons'))
        time.sleep(2)
        #dp.update(0,"","Installing selections.....")
        print '======================================='
        print addonfolder
        print '======================================='
        extract.all(lib,addonfolder,'')
        
def DEPENDINSTALL(name,url,description,filetype,repourl):
        #Split Script Depends============================
        files=url.split('/')
        dependname = files[-1:]
        dependname = str(dependname)
        dependname = dependname.replace('[','').replace(']','').replace('"','').replace('[','').replace("'",'').replace(".zip",'')
        #StoprSplit======================================
        path=xbmc.translatePath(os.path.join('special://home/addons','packages'))
        dp=xbmcgui.DialogProgress()
        dp.create("Configuring Requirments:","Downloading and ",'','Installing '+ name)
        lib=os.path.join(path,name+'.zip')
        try: os.remove(lib)
        except: pass
        downloader.download(url, lib, dp)
        if filetype == 'addon':
            addonfolder = xbmc.translatePath(os.path.join('special://','home/addons'))
        time.sleep(2)
        #dp.update(0,"","Installing selections.....")
        print '======================================='
        print addonfolder
        print '======================================='
        extract.all(lib,addonfolder,'')
        #Start Script Depend Search==================================================================
        depends=xbmc.translatePath(os.path.join('special://home/addons/'+dependname,'addon.xml'))    
        source= open( depends, mode = 'r' )
        link = source . read( )
        source . close ( )
        dmatch=re.compile('import addon="(.+?)"').findall(link)
        for requires in dmatch:
            if not 'xbmc.python' in requires:
                print 'Script Requires --- ' + requires
                dependspath=xbmc.translatePath(os.path.join('special://home/addons',requires))
                #if not os.path.exists(dependspath): DEPENDINSTALL(requires,'http://addonrepo.com/xbmchub/depends/'+requires+'.zip','','addon','none')
                if not os.path.exists(dependspath): DEPENDINSTALL(requires,'http://tribeca.xbmchub.com/tools/maintenance/modules/'+requires+'.zip','','addon','none')
        #End Script Depend Search====================================================================== 

def ADDONINSTALL(name,url,description,filetype,repourl):
  #Start Depend Setup================================================================================  
  print 'Installing Url is ' +url
  addonfile=url.split('-')
  newfile = addonfile[0:-1]
  newfile = str(newfile)
  folder=newfile.split('/')
  addonname = folder[-1:]
  addonname = str(addonname)
  addonname = addonname.replace('[','').replace(']','').replace('"','').replace('[','').replace("'",'')
  print 'SOURCE FILE IS ' + addonname
  #End of Depend Setup==================================================================================
  path=xbmc.translatePath(os.path.join('special://home/addons','packages'))
  confirm=xbmcgui.Dialog().yesno("Please Confirm","                Do you wish to install the chosen add-on and","                        its respective repository if needed?              ","                    ","Cancel","Install")
  
  if confirm: 
        dp=xbmcgui.DialogProgress()
        dp.create("Download Progress:","Downloading your selection ",'','Please Wait')
        lib=os.path.join(path,name+'.zip')
        try: os.remove(lib)
        except: pass
        downloader.download(url, lib, dp)
        if filetype == 'addon':
            addonfolder = xbmc.translatePath(os.path.join('special://','home/addons'))
        elif filetype == 'media':
             addonfolder = xbmc.translatePath(os.path.join('special://','home'))    
        elif filetype == 'main':
             addonfolder = xbmc.translatePath(os.path.join('special://','home'))
        time.sleep(2)
        #dp.update(0,"","Installing selections.....")
        print '======================================='
        print addonfolder
        print '======================================='
        extract.all(lib,addonfolder,dp)
        try:
            #Start Addon Depend Search==================================================================
            depends=xbmc.translatePath(os.path.join('special://home/addons/'+addonname,'addon.xml'))    
            source= open( depends, mode = 'r' )
            link = source . read( )
            source . close ( )
            dmatch=re.compile('import addon="(.+?)"').findall(link)
            for requires in dmatch:
                if not 'xbmc.python' in requires:
                    print 'Requires --- ' + requires
                    dependspath=xbmc.translatePath(os.path.join('special://home/addons',requires))
                    #if not os.path.exists(dependspath): DEPENDINSTALL(requires,'http://addonrepo.com/xbmchub/depends/'+requires+'.zip','','addon','none')
                    if not os.path.exists(dependspath): DEPENDINSTALL(requires,'http://tribeca.xbmchub.com/tools/maintenance/modules/'+requires+'.zip','','addon','none')
        except:pass            
            #End Addon Depend Search======================================================================    
        #dialog=xbmcgui.Dialog()
        #dialog.ok("Success!","Please Reboot To Take Effect","    Brought To You By totalXBMC.tv ")
#start repo dl
        if  'none' not in repourl:
            path=xbmc.translatePath(os.path.join('special://home/addons','packages'))
  
   
            dp=xbmcgui.DialogProgress()
            dp.create("Updating Repo if needed:","Configuring Installation ",'',' ')
            lib=os.path.join(path,name+'.zip')
            try: os.remove(lib)
            except: pass
            downloader.download(repourl, lib, '')
            if filetype == 'addon':
                addonfolder = xbmc.translatePath(os.path.join('special://','home/addons'))
            elif filetype == 'media':
                 addonfolder = xbmc.translatePath(os.path.join('special://','home'))    
            elif filetype == 'main':
                 addonfolder = xbmc.translatePath(os.path.join('special://','home'))
            time.sleep(2)
            #dp.update(0,"","Checking Installation......")
            print '======================================='
            print addonfolder
            print '======================================='
            extract.all(lib,addonfolder,dp)
            xbmc.executebuiltin("XBMC.UpdateLocalAddons()")
            dialog=xbmcgui.Dialog()
            dialog.ok("Success!","     Your Selections Have Been Installed","    Brought To You By totalXBMC.tv ")
        else:
            xbmc.executebuiltin("XBMC.UpdateLocalAddons()")
            dialog=xbmcgui.Dialog()
            dialog.ok("Success!","     Your Selections Have Been Installed","    Brought To You By totalXBMC.tv ")
        '''confirm=xbmcgui.Dialog().yesno("Success!","                Please Restart To Take Effect","                        Brought To You By totalXBMC.tv              ","                    ","Later","Restart")
        if confirm:
               xbmc.executebuiltin('Quit')
         
        else:
            pass'''
            
        
  else:
      return


    


# Set View
def AUTO_VIEW(content):
     if content:
          xbmcplugin.setContent(int(sys.argv[1]), content)
          if settings.getSetting('auto-view') == 'true':
               if content == 'addons':
                    xbmc.executebuiltin("Container.SetViewMode(%s)" % settings.getSetting('addon_view'))
               else:
                    xbmc.executebuiltin("Container.SetViewMode(%s)" % settings.getSetting('default-view'))


  


# HELPDIR**************************************************************
def addDir(name,url,mode,thumb):        
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=thumb)
        #liz.setInfo( type="Video", infoLabels={ "title": name, "Plot": description } )
        try:
             liz.setProperty( "Fanart_Image", fanart )
        except:
             pass
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok  


def addHELPDir(name,url,mode,iconimage,fanart,description,filetype,repourl,version,author):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&filetype="+urllib.quote_plus(filetype)+"&repourl="+urllib.quote_plus(repourl)+"&author="+urllib.quote_plus(author)+"&version="+urllib.quote_plus(version)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "title": name, "plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        liz.setProperty( "Addon.Description", description )
        liz.setProperty( "Addon.Creator", author )
        liz.setProperty( "Addon.Version", version )
        #properties = { 'Addon.Description':meta["plot"]}
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

def add2HELPDir(name,url,mode,iconimage,fanart,description,filetype):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&filetype="+urllib.quote_plus(filetype)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok          

  



#Start Ketboard Function                
def _get_keyboard( default="", heading="", hidden=False ):
	""" shows a keyboard and returns a value """
	keyboard = xbmc.Keyboard( default, heading, hidden )
	keyboard.doModal()
	if ( keyboard.isConfirmed() ):
		return unicode( keyboard.getText(), "utf-8" )
	return default


#Start Search Function
def SEARCHADDON(url):
	searchUrl = url 
	vq = _get_keyboard( heading="Search add-ons" )
	# if blank or the user cancelled the keyboard, return
	if ( not vq ): return False, 0
	# we need to set the title to our query
	title = urllib.quote_plus(vq)
	searchUrl += title + '&criteria=title' 
	print "Searching URL: " + searchUrl 
	ADDONLIST(searchUrl)

	AUTO_VIEW('list')

	
  

#****************************************************************
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]; cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'): params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&'); param={}
                for i in range(len(pairsofparams)):
                        splitparams={}; splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2: param[splitparams[0]]=splitparams[1]
        return param

params=get_params(); url=None; name=None; mode=None; year=None; imdb_id=None

try:    iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try:    fanart=urllib.unquote_plus(params["fanart"])
except: pass
try:    description=urllib.unquote_plus(params["description"])
except: pass
try:    filetype=urllib.unquote_plus(params["filetype"])
except: pass
try:		url=urllib.unquote_plus(params["url"])
except: pass
try:		name=urllib.unquote_plus(params["name"])
except: pass
try:		mode=urllib.unquote_plus(params["mode"])
except: pass
try:    repourl=urllib.unquote_plus(params["repourl"])
except: pass
try:    author=urllib.unquote_plus(params["author"])
except: pass
try:    version=urllib.unquote_plus(params["version"])
except: pass


print "Mode: "+str(mode); print "URL: "+str(url); print "Name: "+str(name)

#if mode==None or url==None or len(url)<1: STATUSCATS()
if mode==None or url==None or len(url)<1: MAININDEX()

#****************************************************************    


if mode == "addonstatus": print""+url; items=ADDONSTATUS(url)
elif mode=='others': print""+url; items=OTHERS()
elif mode=='categories': print""+url; items=CATEGORIES()
elif mode=='metadata': print""+url; items=METADATA()
elif mode=='genres': print""+url; items=GENRES()
elif mode=='gaming': print""+url; items=GAMING()
elif mode=='music': print""+url; items=MUSIC()
elif mode=='countries': print""+url; items=COUNTRIES()
elif mode=='settings':  addon.show_settings()
elif mode=='featuredindex': print""+url; items=FEATUREDINDEX(url)
elif mode=='featuredaddons': print""+url; items=FEATUREDADDONS(url)
elif mode=='addonlistnext': print""+url; items=ADDONLISTNEXT(url)
elif mode=='addonlist': print""+url; items=ADDONLIST(url)
elif mode=='programlist': print""+url; items=PROGRAMLIST(url)
elif mode=='worldlist': print""+url; items=WORLDLIST(url)
elif mode=='worldalone': print""+url; items=WORLDALONE(url)
elif mode=='otherlist': print""+url; items=OTHERLIST(url)
elif mode=='repolist': print""+url; items=REPOLIST(url)
elif mode=='searchaddon': print""+url; SEARCHADDON(url)
elif mode=='addonindex': print""+url; ADDONINDEX(name,url,filetype)
elif mode=='getrepolink': print""+url; items=GETREPOLINK(url)
elif mode=='getrepolist': print""+url; items=GETREPOLIST(url)
elif mode=='getaddonlink': print""+url; items=GETADDONLINK(url)
elif mode=='getshorts': print""+url; items=GETSHORTS(url)
elif mode=='getrepo': GETREPO(name,url,description,filetype)
elif mode=='getvideolink': print""+url; items=GETVIDEOLINK(url)
elif mode=='getvideo': GETVIDEO(name,url,iconimage,description,filetype)
elif mode=='addoninstall': ADDONINSTALL(name,url,description,filetype,repourl)
elif mode=='listrepoitems': print""+url; items=LISTREPOITEMS(name,url,description,filetype,repourl)
elif mode=='addshortcuts': ADDSHORTCUTS(name,url,description,filetype)
elif mode=='addsource': ADDSOURCE(name,url,description,filetype)
elif mode=='playstream': PLAYSTREAM(name,url,iconimage,description)
elif mode=='adultlist': print""+url; items=ADULTLIST(url)
elif mode=='adultallow': print ""+url; ADULTALLOW(url)
elif mode=='dependinstall': DEPENDINSTALL(name,url,description,filetype,repourl)
xbmcplugin.endOfDirectory(int(sys.argv[1])) 
